export const colors = {
  ivory: "#EAE3D8",
  stone: "#7B786C",
  earth: "#806054",
  charcoal: "#211C19",

  bg: {
    ivory: "bg-[#D2BFB2]",
    stone: "bg-[#7B786C]",
    earth: "bg-[#806054]",
    charcoal: "bg-[#211C19]",
    charcoal70: "bg-[#211C19]/70",
    empty: "bg-[#B3A193]/30",
    empty70: "bg-[#B3A193]/70",
  },

  text: {
    ivory: "text-[#EAE3D8]",
    stone: "text-[#7B786C]",
    earth: "text-[#806054]",
    charcoal: "text-[#211C19]",
    charcoal70: "text-[#211C19]/60",
  },

  border: {
    ivory: "border-[#EAE3D8]",
    stone: "border-[#7B786C]",
    earth: "border-[#806054]",
    charcoal: "border-[#211C19]",
  },

  input: {
    border: "border-black/30",
    placeholder: "placeholder:text-[#211C19]",
    number: "text-[#EAE3D8]",
  },

  feedback: {
    error: "text-[#5A2B2B]",
    success: "text-[#323E23]",
  },
};
