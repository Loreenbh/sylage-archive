// src/styles/geometry.ts

export const geometry = {
  // Conteneur Header universel
  header: {
    container: "w-full h-10 md:h-12 lg:h-20 xl:h-28 shrink-0 flex items-center justify-between relative",
    titleWrapper: "relative h-6 md:h-8 lg:h-14 xl:h-20 w-auto flex items-center",
  },

  // Zone Body (Zone sous le header)
  body: {
    container: "relative flex flex-1 min-h-0 w-full overflow-hidden mt-2 md:mt-4 lg:mt-6",
    mainArea: "flex flex-col min-w-0 flex-1 h-full justify-between",
    contentSquare: "w-[82%] sm:w-[85%] aspect-square min-h-0 relative",
  },

  // Sidebar universelle
  sidebar: {
    container: "absolute top-0 right-0 h-full w-7 md:w-8 lg:w-10 xl:w-16 pointer-events-none flex flex-col justify-between items-center",
    content: "h-full w-full pointer-events-auto flex flex-col items-center justify-between",
  },

  // Action Bar universelle
  actionBar: {
    container: "w-full pt-1 md:pt-2 lg:pt-3 flex items-center min-h-[24px] lg:min-h-[32px]",
  },

  // Footer universel
  footer: {
    container: "shrink-0 w-full flex justify-between items-center px-2 md:px-4 min-h-[20px] lg:min-h-[28px] mt-auto",
  },
};