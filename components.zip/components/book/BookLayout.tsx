// src/components/book/BookLayout.tsx
import BookFrame from "./BookFrame";
import { geometry } from "@/styles/geometry";

type Props = {
  header?: React.ReactNode;
  children: React.ReactNode;
  sidebar?: React.ReactNode;
  actionsBar?: React.ReactNode;
  imageClassName?: string;
  sidebarClassName?: string;
  footerLeft?: React.ReactNode;
  footerRight?: React.ReactNode;
};

export default function BookLayout({
  header,
  children,
  sidebar,
  actionsBar,
  footerLeft,
  footerRight,
  imageClassName,
  sidebarClassName,
}: Props) {
  return (
    <BookFrame>
      {/* HEADER */}
      {header && <div className={geometry.header.container}>{header}</div>}

      {/* BODY */}
      <div className={geometry.body.container}>
        {/* CONTENU PRINCIPAL + ACTIONS */}
        <div className={geometry.body.mainArea}>
          <div className={`${geometry.body.contentSquare} ${imageClassName ?? ""}`}>
            {children}
          </div>

          {actionsBar && <div className={geometry.actionBar.container}>{actionsBar}</div>}
        </div>

        {/* SIDEBAR */}
        {sidebar && (
          <div className={`${geometry.sidebar.container} ${sidebarClassName ?? ""}`}>
            <div className={geometry.sidebar.content}>{sidebar}</div>
          </div>
        )}
      </div>

      {/* FOOTER */}
      {(footerLeft || footerRight) && (
        <div className={geometry.footer.container}>
          <div className="flex items-center min-w-0">{footerLeft}</div>
          <div className="flex items-center min-w-0">{footerRight}</div>
        </div>
      )}
    </BookFrame>
  );
}