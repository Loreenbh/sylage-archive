// src/components/pages/Cover.tsx
import Image from "next/image";
import type { OnNavigate } from "@/types/navigation";
import BookLayout from "@/components/book/BookLayout";
import Sidebar from "@/components/navigation/SideBar";
import SimpleGrid from "@/components/ui/grids/SimpleGrid";
import { typography } from "@/styles/typography";
import { colors } from "@/styles/colors";

type Props = {
  onNavigate: OnNavigate;
};

export default function Cover({ onNavigate }: Props) {
  return (
    <BookLayout
      header={
        <div className="w-full h-full flex items-center justify-between relative">
          {/* PORTFOLIO */}
          <button
            onClick={() => {
              window.location.href = "https://sylage-world.vercel.app/";
            }}
            className="text-[9px] md:text-[11px] lg:text-[14px] xl:text-[18px] tracking-[0.18em] text-black/20 hover:text-black/50 transition-colors duration-300 cursor-pointer"
          >
            ← PORTFOLIO
          </button>

          {/* TITRE CENTRAL */}
          <div className="flex flex-col items-center justify-center">
            <div className="relative h-5 md:h-7 lg:h-12 xl:h-16 w-32 md:w-48 lg:w-72 xl:w-96">
              <Image
                src="/title.png"
                alt="SYLAGE"
                fill
                priority
                className="object-contain object-center"
              />
            </div>
            <p className={`${typography.subtitle} ${colors.text.charcoal}`}>
              ARCHIVE
            </p>
          </div>

          <div className="w-12" /> {/* Équilibreur flex */}
        </div>
      }
      sidebar={<Sidebar text="↓   26|27" clickable onNavigate={onNavigate} />}
      actionsBar={
        <p className={`${typography.actionBar} ${colors.text.charcoal}`}>
          A visual archive of moods
        </p>
      }
    >
      <div className="flex flex-col h-full w-full">
        <SimpleGrid
          square={
            <div className="flex h-full w-full justify-center relative">
              <Image
                src="/cover.png"
                alt=""
                fill
                priority
                className="object-contain"
              />
            </div>
          }
        />
      </div>
    </BookLayout>
  );
}